# Aerofit Business Case – Descriptive Statistics & Probability

## Project Overview
This project analyzes customer characteristics for Aerofit treadmill products using descriptive statistics and probability analysis. The objective is to understand customer behavior and help the company recommend suitable treadmills to new customers.

## Business Objectives
- Understand customer characteristics across Aerofit treadmill products.
- Compare customer demographics, income, fitness levels, and usage patterns.
- Analyze product preference using probability and conditional probability.
- Develop customer profiles and business recommendations.

## Dataset
The dataset contains customer purchase information for Aerofit treadmills, including demographic, income, and fitness-related variables. The report states that no missing values were observed and that categorical columns were converted to category data types for analysis.

## Tools & Techniques
- Python
- Pandas and NumPy
- Matplotlib and Seaborn
- Descriptive Statistics
- Exploratory Data Analysis (EDA)
- Probability and Conditional Probability
- Correlation Analysis
- Customer Segmentation

## Analysis Performed
- Product distribution analysis
- Customer age, income, fitness, and miles analysis
- Product comparisons by gender, income, fitness, and usage
- Correlation analysis using a heatmap
- Probability of purchasing each treadmill product
- Conditional probability by customer gender
- Customer profiling and business recommendations

## Key Findings
- KP281 has the highest number of purchases and is the most popular entry-level treadmill.
- Most customers are between 20 and 35 years old.
- Income distribution is right-skewed.
- KP781 customers tend to have higher income, fitness ratings, and weekly usage.
- Fitness and miles show a strong positive correlation.
- The report finds a higher probability of male customers purchasing KP781 compared with female customers.
- Partnered customers show a slightly higher preference for mid-range and premium treadmills.

## Customer Segmentation
| Product | Target Customer | Key Characteristics |
|---|---|---|
| KP281 | Beginners | Young, lower income, moderate usage |
| KP481 | Regular users | Middle income, consistent workouts |
| KP781 | Advanced users | Higher income, higher fitness, heavier usage |

## Business Recommendations
- Position KP281 as an affordable, beginner-friendly treadmill.
- Promote KP481 as a value-for-money upgrade for regular fitness users.
- Target high-income fitness enthusiasts with premium KP781 marketing.
- Use income, fitness level, and usage patterns to personalize product recommendations.
- Improve customer engagement with suitable workout plans and services.

## Repository Structure
```text
aerofit-business-case-analysis/
├── README.md
└── report/
    └── Aerofit_Descriptive_Statistics_Probability_Report.pdf
```

## Project Report
See the `report/` folder for the detailed project report.

## Author
Data Analytics Portfolio Project
